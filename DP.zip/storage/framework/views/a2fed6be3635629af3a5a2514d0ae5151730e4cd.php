<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Rediģēt Pieteikumu</title>
        <link rel="shortcut icon" href="<?php echo e(asset('images/icon.png')); ?>"/>

        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        
</head>
<body style="background-color: #ffd600;">
<div class="container mt-5">
    <form action="/pieteikumi/<?php echo e($anketa->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <div class="form-group">
        <label>Vieta un Datums *</label>
        <?php $__currentLoopData = $allDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check">
            
                
                

                    <input class="form-check-input" type="checkbox" value="<?php echo e($oneDate); ?>" name="date[]">
                    <label class="form-check-label"><?php echo e($oneDate); ?></label>
                    
                
                

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $datumi[0]->date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($date); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="form-row mb-3">
            <div class="col">
                <!-- First name -->
                <label class="label" for="name">Vārds *</label>
                <input class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="name" 
                    id="name"
                    value="<?php echo e($anketa->name); ?>"
                    placeholder="Ievadiet savu vārdu">
                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col">
                <!-- Last name -->
                <label class="label" for="surname">Uzvārds *</label>
                <input class="form-control <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="surname" 
                    id="surname"
                    value="<?php echo e($anketa->surname); ?>"
                    placeholder="Ievadiet savu uzvārdu">
                <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?>
                <p class="text-danger"><?php echo e($errors->first('surname')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="carnumber">Automašīnas Reģistrācijas Numurs *</label>
            <div>
                <input class="form-control <?php if ($errors->has('carnumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('carnumber'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="carnumber" 
                    id="carnumber"
                    value="<?php echo e($anketa->carnumber); ?>"
                    placeholder="Ievadiet automašīnas reģistrācijas numuru">
                <?php if ($errors->has('carnumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('carnumber'); ?>
                <p class="text-danger"><?php echo e($errors->first('carnumber')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="email">E-pasta adrese *</label>
            <div>
                <input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="email" 
                    name="email" 
                    id="email"
                    value="<?php echo e($anketa->email); ?>"
                    placeholder="Ievadiet savu e-pasta adresi">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="number">Tālruņa numurs *</label>
            <div>
                <input class="form-control <?php if ($errors->has('number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('number'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="number" 
                    id="number"
                    value="<?php echo e($anketa->number); ?>"
                    placeholder="Ievadiet savu tālruņa numuru">
                <?php if ($errors->has('number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('number'); ?>
                <p class="text-danger"><?php echo e($errors->first('number')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="comment">Komentāri</label>
                    <textarea class="form-control <?php if ($errors->has('error')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('error'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="comment" id="comment" rows="3"><?php echo e($anketa->comment); ?></textarea>
                <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?>
                <p class="text-danger"><?php echo e($errors->first('comment')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group mt-4">
            <button type="submit" class="btn btn-success">Saglabāt</button>
        </div>
    </form>
</div>
</body>
</html><?php /**PATH C:\Users\Hydratype\Desktop\Coding\DubultPrieks\resources\views/anketa/edit.blade.php ENDPATH**/ ?>