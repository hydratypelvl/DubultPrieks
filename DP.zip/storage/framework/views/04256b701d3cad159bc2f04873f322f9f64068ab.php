<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.12.1/js/all.js" crossorigin="anonymous"></script>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset ('css/styles.css')); ?>" />
</head>
<body>
<!-- Navigation-->
<nav class="navbar navbar-expand-lg bg-secondary text-uppercase" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top">Tev & Man</a><button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">Menu <i class="fas fa-bars"></i></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="/anketa">Pieteikties</a></li>
                        <?php if(Auth::user()): ?>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="/pieteikumi">Pieteikumi</a></li>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle py-3 px-0 px-lg-3 rounded" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
        </nav>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col">
            Kopā aizpildītās anketas: <?php echo e($pieteikumi); ?>

        </div>
        <div class="col">
            Kopā aizpildītās anketas: <?php echo e($pieteikumi); ?>

        </div>
        <div class="col">
            Kopā aizpildītās anketas: <?php echo e($pieteikumi); ?>

        </div>
    </div>
    
    <table class="table table-striped table-dark table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Vārds</th>
                <th scope="col">Uzvārds</th>
                <th scope="col">Tālrunis</th>
                <th scope="col">Datums</th>
                <th scope="col">NR</th>
                <th scope="col">E-pasts</th>
                <th scope="col">Info</th>
                <th scope="col">Edit</th>
                <th scope="col">Dzēst</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $anketas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anketa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($anketa->id); ?></th>
                <td><?php echo e($anketa->name); ?></td>
                <td><?php echo e($anketa->surname); ?></td>
                <td><?php echo e($anketa->number); ?></td>
                <td>
                <?php $__currentLoopData = $anketa->date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datums): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($datums); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                <td><?php echo e($anketa->carnumber); ?></td>
                <td><?php echo e($anketa->email); ?></td>
                <td><a href="/pieteikumi/<?php echo e($anketa->id); ?>" class="btn btn-primary"><i class="fas fa-info"></i></a></td>
                <td><a href="/pieteikumi/edit/<?php echo e($anketa->id); ?>" class="btn btn-warning"><i class="far fa-edit"></i></a></td>
                <td>
                    <form action="/pieteikumi/<?php echo e($anketa->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" onclick="return confirm('Vai tiešām vēlaties dzēst šo pieteikumu?')"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($anketas->links()); ?>

    <!-- Bootstrap core JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <!-- Third party plugin JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <!-- Scripts -->
    <script src="js/scripts.js"></script>
</body>
</html><?php /**PATH C:\Users\Hydratype\Desktop\Coding\DubultPrieks\resources\views/anketa/index.blade.php ENDPATH**/ ?>