<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DubultPrieks</title>
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.12.1/js/all.js" crossorigin="anonymous"></script>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset ('css/styles.css')); ?>" />
</head>
<?php echo $__env->yieldContent('content'); ?><?php /**PATH C:\Users\Hydratype\Desktop\Coding\DubultPrieks\resources\views/layouts/head.blade.php ENDPATH**/ ?>