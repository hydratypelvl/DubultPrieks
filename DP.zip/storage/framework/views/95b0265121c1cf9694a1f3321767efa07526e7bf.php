<?php $__env->startSection('content'); ?>
<body>
<div class="container">

<p class="float-right mt-5">Pievienot jaunu datumu <a href="/datumi/create" class="btn btn-success"><i class="fas fa-plus"></i></a></p>
    <table class="table table-bordered table-striped table-hover    ">
    <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Datums</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
        
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <th scope="row"><?php echo e($date->id); ?></th>
        <td><?php echo e($date->date); ?></td>
        <td align="center"><button disabled class="btn btn-warning"><i class="far fa-edit"></i></button></td>
        <td align="center">
            <form action="/datumi/<?php echo e($date->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger" onclick="return confirm('Vai tiešām vēlaties dzēst šo datumu?')"><i class="far fa-trash-alt"></i></button>
            </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hydratype\Desktop\Coding\DubultPrieks\resources\views/datumi/index.blade.php ENDPATH**/ ?>