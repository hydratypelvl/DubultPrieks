<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Tev & Man</title>
        <link rel="shortcut icon" href="<?php echo e(asset('images/icon.png')); ?>"/>

        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        
</head>
<body style="background-color: #ffd600;">
<div class="container mt-5">
    <form action="/anketa" method="post">
    <?php echo csrf_field(); ?>
        <div class="form-group">
        <label>Vieta un Datums *</label>
        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check">
                <input class="form-check-input" type="checkbox" value="<?php echo e($date->date); ?>" name="date[]">
                <label class="form-check-label"><?php echo e($date->date); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
            <p class="text-danger"><?php echo e($errors->first('date')); ?></p>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-row mb-3">
            <div class="col">
                <!-- First name -->
                <label class="label" for="name">Vārds *</label>
                <input class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="name" 
                    id="name"
                    value="<?php echo e(old('name')); ?>"
                    placeholder="Ievadiet savu vārdu">
                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col">
                <!-- Last name -->
                <label class="label" for="surname">Uzvārds *</label>
                <input class="form-control <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="surname" 
                    id="surname"
                    value="<?php echo e(old('surname')); ?>"
                    placeholder="Ievadiet savu uzvārdu">
                <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?>
                <p class="text-danger"><?php echo e($errors->first('surname')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="carnumber">Automašīnas Reģistrācijas Numurs *</label>
            <div>
                <input class="form-control <?php if ($errors->has('carnumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('carnumber'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="carnumber" 
                    id="carnumber"
                    value="<?php echo e(old('carnumber')); ?>"
                    placeholder="Ievadiet automašīnas reģistrācijas numuru">
                <?php if ($errors->has('carnumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('carnumber'); ?>
                <p class="text-danger"><?php echo e($errors->first('carnumber')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="email">E-pasta adrese *</label>
            <div>
                <input class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="email" 
                    name="email" 
                    id="email"
                    value="<?php echo e(old('email')); ?>"
                    placeholder="Ievadiet savu e-pasta adresi">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="number">Tālruņa numurs *</label>
            <div>
                <input class="form-control <?php if ($errors->has('number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('number'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                    type="text" 
                    name="number" 
                    id="number"
                    value="<?php echo e(old('number')); ?>"
                    placeholder="Ievadiet savu tālruņa numuru">
                <?php if ($errors->has('number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('number'); ?>
                <p class="text-danger"><?php echo e($errors->first('number')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label class="label" for="comment">Komentāri</label>
                    <textarea class="form-control <?php if ($errors->has('error')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('error'); ?> border-danger <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="comment" id="comment" rows="3"><?php echo e(old('comment')); ?></textarea>
                <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?>
                <p class="text-danger"><?php echo e($errors->first('comment')); ?></p>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group mt-4">
            <button type="submit" class="btn btn-primary mr-4">Nosūtīt</button>
            <a href="/" type="submit" class="btn btn-danger">Atgriezties</a>
        </div>
    </form>
</div>
</body>
</html><?php /**PATH C:\Users\Hydratype\Desktop\Coding\DubultPrieks\resources\views/anketa/create.blade.php ENDPATH**/ ?>